
<!DOCTYPE html>
<html class="html" lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<title>Page not found</title>
<meta name="viewport" content="width=device-width, initial-scale=1"><link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Feed" href="https://learnwithrobiul.com/feed/" />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Comments Feed" href="https://learnwithrobiul.com/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v7.11.0 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
	var mi_version         = '7.11.0';
	var mi_track_user      = true;
	var mi_no_track_reason = '';
	
	var disableStr = 'ga-disable-UA-162916199-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}

	if ( 'undefined' === typeof gaOptout ) {
		function gaOptout() {
			__gaTrackerOptout();
		}
	}
	
	if ( mi_track_user ) {
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

		__gaTracker('create', 'UA-162916199-1', 'auto');
		__gaTracker('set', 'forceSSL', true);
		__gaTracker('require', 'displayfeatures');
		__gaTracker('require', 'linkid', 'linkid.js');
		__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
	} else {
		console.log( "" );
		(function() {
			/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
			var noopfn = function() {
				return null;
			};
			var noopnullfn = function() {
				return null;
			};
			var Tracker = function() {
				return null;
			};
			var p = Tracker.prototype;
			p.get = noopfn;
			p.set = noopfn;
			p.send = noopfn;
			var __gaTracker = function() {
				var len = arguments.length;
				if ( len === 0 ) {
					return;
				}
				var f = arguments[len-1];
				if ( typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function' ) {
					console.log( 'Not running function __gaTracker(' + arguments[0] + " ....) because you are not being tracked. " + mi_no_track_reason );
					return;
				}
				try {
					f.hitCallback();
				} catch (ex) {

				}
			};
			__gaTracker.create = function() {
				return new Tracker();
			};
			__gaTracker.getByName = noopnullfn;
			__gaTracker.getAll = function() {
				return [];
			};
			__gaTracker.remove = noopfn;
			window['__gaTracker'] = __gaTracker;
					})();
		}
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/learnwithrobiul.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.2"}};
			/*! This file is auto-generated */
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://learnwithrobiul.com/wp-includes/css/dist/block-library/style.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='https://learnwithrobiul.com/wp-includes/css/dist/block-library/theme.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://learnwithrobiul.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=2.5.16' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://learnwithrobiul.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.2' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://learnwithrobiul.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.0.9' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='wpcf-slick-css'  href='https://learnwithrobiul.com/wp-content/plugins/wp-carousel-free/public/css/slick.min.css?ver=2.1.9' type='text/css' media='all' />
<link rel='stylesheet' id='wp-carousel-free-fontawesome-css'  href='https://learnwithrobiul.com/wp-content/plugins/wp-carousel-free/public/css/font-awesome.min.css?ver=2.1.9' type='text/css' media='all' />
<link rel='stylesheet' id='wp-carousel-free-css'  href='https://learnwithrobiul.com/wp-content/plugins/wp-carousel-free/public/css/wp-carousel-free-public.min.css?ver=2.1.9' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-style-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='child-style-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp-child/style.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=5.11.2' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=2.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/third/magnific-popup.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/third/slick.min.css?ver=1.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-woo-mini-cart-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/woo/woo-mini-cart.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-woocommerce-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/woo/woocommerce.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-woo-star-font-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/woo/woo-star-font.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-woo-quick-view-css'  href='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/css/woo/woo-quick-view.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-google-font-open-sans-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100i%2C200i%2C300i%2C400i%2C500i%2C600i%2C700i%2C800i%2C900i&#038;subset=latin&#038;ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='oceanwp-google-font-poppins-css'  href='//fonts.googleapis.com/css?family=Poppins%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100i%2C200i%2C300i%2C400i%2C500i%2C600i%2C700i%2C800i%2C900i&#038;subset=latin&#038;ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='https://learnwithrobiul.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.1' type='text/css' media='all' />
<link rel='stylesheet' id='popup-maker-site-css'  href='//learnwithrobiul.com/wp-content/uploads/pum/pum-site-styles.css?generated=1593529220&#038;ver=1.11.0' type='text/css' media='all' />
<link rel='stylesheet' id='oe-widgets-style-css'  href='https://learnwithrobiul.com/wp-content/plugins/ocean-extra/assets/css/widgets.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='osh-styles-css'  href='https://learnwithrobiul.com/wp-content/plugins/ocean-sticky-header/assets/css/style.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='learn-press-bundle-css'  href='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/css/bundle.min.css?nocache=1601382888.9337&#038;ver=3.2.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='learn-press-css'  href='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/css/learnpress.css?nocache=1601382888.9337&#038;ver=3.2.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='igniteup-front-compulsory-css'  href='https://learnwithrobiul.com/wp-content/plugins/igniteup/includes/css/front-compulsory.css?ver=3.4.1' type='text/css' media='all' />
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>Sorry, this product is unavailable. Please choose a different combination.</p>
</script>
    <script>window.LP_DEBUG = true;</script>
	<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","download_extensions":"doc,pdf,ppt,zip,xls,docx,pptx,xlsx","inbound_paths":"[{\"path\":\"\\\/go\\\/\",\"label\":\"affiliate\"},{\"path\":\"\\\/recommend\\\/\",\"label\":\"affiliate\"}]","home_url":"https:\/\/learnwithrobiul.com","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js?ver=7.11.0'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/revslider/public/assets/js/revolution.tools.min.js?ver=6.0'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.0.9'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/learnwithrobiul.com\/cart\/","is_cart":"","cart_redirect_after_add":"yes"};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.2.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/learnpress-woo-payment/assets/script.js?ver=5.4.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.1'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/underscore.min.js?ver=1.8.3'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/js/vendor/plugins.all.js?nocache=1601382888.9337&#038;ver=3.2.7.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var userSettings = {"url":"\/","uid":"0","time":"1601382888","secure":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/utils.min.js?ver=5.4.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var lpGlobalSettings = {"url":"https:\/\/learnwithrobiul.com\/blog\/linkid.js\/","siteurl":"https:\/\/learnwithrobiul.com","ajax":"https:\/\/learnwithrobiul.com\/wp-admin\/admin-ajax.php","theme":"oceanwp-child","localize":{"button_ok":"OK","button_cancel":"Cancel","button_yes":"Yes","button_no":"No"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/js/global.js?nocache=1601382888.9337&#038;ver=3.2.7.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/js/utils.js?nocache=1601382888.9337&#038;ver=3.2.7.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/js/frontend/learnpress.js?nocache=1601382888.9337&#038;ver=3.2.7.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/js/frontend/course.js?nocache=1601382888.9337&#038;ver=3.2.7.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/learnpress/assets/js/frontend/become-teacher.js?nocache=1601382888.9337&#038;ver=3.2.7.2'></script>
<link rel='https://api.w.org/' href='https://learnwithrobiul.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://learnwithrobiul.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://learnwithrobiul.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.2" />
<meta name="generator" content="WooCommerce 4.2.2" />
<script type="text/javascript">igniteup_ajaxurl = "https://learnwithrobiul.com/wp-admin/admin-ajax.php";</script>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.0.9 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://learnwithrobiul.com/wp-content/uploads/2020/02/faveicon.png" sizes="32x32" />
<link rel="icon" href="https://learnwithrobiul.com/wp-content/uploads/2020/02/faveicon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://learnwithrobiul.com/wp-content/uploads/2020/02/faveicon.png" />
<meta name="msapplication-TileImage" content="https://learnwithrobiul.com/wp-content/uploads/2020/02/faveicon.png" />
<script type="text/javascript">function setREVStartSize(a){try{var b,c=document.getElementById(a.c).parentNode.offsetWidth;if(c=0===c||isNaN(c)?window.innerWidth:c,a.tabw=void 0===a.tabw?0:parseInt(a.tabw),a.thumbw=void 0===a.thumbw?0:parseInt(a.thumbw),a.tabh=void 0===a.tabh?0:parseInt(a.tabh),a.thumbh=void 0===a.thumbh?0:parseInt(a.thumbh),a.tabhide=void 0===a.tabhide?0:parseInt(a.tabhide),a.thumbhide=void 0===a.thumbhide?0:parseInt(a.thumbhide),a.mh=void 0===a.mh||""==a.mh?0:a.mh,"fullscreen"===a.layout||"fullscreen"===a.l)b=Math.max(a.mh,window.innerHeight);else{for(var d in a.gw=Array.isArray(a.gw)?a.gw:[a.gw],a.rl)(void 0===a.gw[d]||0===a.gw[d])&&(a.gw[d]=a.gw[d-1]);for(var d in a.gh=void 0===a.el||""===a.el||Array.isArray(a.el)&&0==a.el.length?a.gh:a.el,a.gh=Array.isArray(a.gh)?a.gh:[a.gh],a.rl)(void 0===a.gh[d]||0===a.gh[d])&&(a.gh[d]=a.gh[d-1]);var e,f=Array(a.rl.length),g=0;for(var d in a.tabw=a.tabhide>=c?0:a.tabw,a.thumbw=a.thumbhide>=c?0:a.thumbw,a.tabh=a.tabhide>=c?0:a.tabh,a.thumbh=a.thumbhide>=c?0:a.thumbh,a.rl)f[d]=a.rl[d]<window.innerWidth?0:a.rl[d];for(var d in e=f[0],f)e>f[d]&&0<f[d]&&(e=f[d],g=d);var h=c>a.gw[g]+a.tabw+a.thumbw?1:(c-(a.tabw+a.thumbw))/a.gw[g];b=a.gh[g]*h+(a.tabh+a.thumbh)}void 0===window.rs_init_css&&(window.rs_init_css=document.head.appendChild(document.createElement("style"))),document.getElementById(a.c).height=b,window.rs_init_css.innerHTML+="#"+a.c+"_wrapper { height: "+b+"px }"}catch(a){console.log("Failure at Presize of Slider:"+a)}};</script>
		<style type="text/css" id="wp-custom-css">
			@media only screen and (max-width:767px){body:not(.logged-in) #learn-press-user-profile >div{width:100%}}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><!-- OceanWP CSS -->
<style type="text/css">
/* General CSS */.woocommerce-MyAccount-navigation ul li a:before,.woocommerce-checkout .woocommerce-info a,.woocommerce-checkout #payment ul.payment_methods .wc_payment_method>input[type=radio]:first-child:checked+label:before,.woocommerce-checkout #payment .payment_method_paypal .about_paypal,.woocommerce ul.products li.product li.category a:hover,.woocommerce ul.products li.product .button:hover,.woocommerce ul.products li.product .product-inner .added_to_cart:hover,.product_meta .posted_in a:hover,.product_meta .tagged_as a:hover,.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,.woocommerce .oceanwp-grid-list a.active,.woocommerce .oceanwp-grid-list a:hover,.woocommerce .oceanwp-off-canvas-filter:hover,.widget_shopping_cart ul.cart_list li .owp-grid-wrap .owp-grid a.remove:hover,.widget_product_categories li a:hover ~ .count,.widget_layered_nav li a:hover ~ .count,.woocommerce ul.products li.product:not(.product-category) .woo-entry-buttons li a:hover,a:hover,a.light:hover,.theme-heading .text::before,#top-bar-content >a:hover,#top-bar-social li.oceanwp-email a:hover,#site-navigation-wrap .dropdown-menu >li >a:hover,#site-header.medium-header #medium-searchform button:hover,.oceanwp-mobile-menu-icon a:hover,.blog-entry.post .blog-entry-header .entry-title a:hover,.blog-entry.post .blog-entry-readmore a:hover,.blog-entry.thumbnail-entry .blog-entry-category a,ul.meta li a:hover,.dropcap,.single nav.post-navigation .nav-links .title,body .related-post-title a:hover,body #wp-calendar caption,body .contact-info-widget.default i,body .contact-info-widget.big-icons i,body .custom-links-widget .oceanwp-custom-links li a:hover,body .custom-links-widget .oceanwp-custom-links li a:hover:before,body .posts-thumbnails-widget li a:hover,body .social-widget li.oceanwp-email a:hover,.comment-author .comment-meta .comment-reply-link,#respond #cancel-comment-reply-link:hover,#footer-widgets .footer-box a:hover,#footer-bottom a:hover,#footer-bottom #footer-bottom-menu a:hover,.sidr a:hover,.sidr-class-dropdown-toggle:hover,.sidr-class-menu-item-has-children.active >a,.sidr-class-menu-item-has-children.active >a >.sidr-class-dropdown-toggle,input[type=checkbox]:checked:before{color:#1998d7}.woocommerce div.product div.images .open-image,.wcmenucart-details.count,.woocommerce-message a,.woocommerce-error a,.woocommerce-info a,.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,.woocommerce .widget_price_filter .ui-slider .ui-slider-range,.owp-product-nav li a.owp-nav-link:hover,.woocommerce div.product.owp-tabs-layout-vertical .woocommerce-tabs ul.tabs li a:after,.woocommerce .widget_product_categories li.current-cat >a ~ .count,.woocommerce .widget_product_categories li.current-cat >a:before,.woocommerce .widget_layered_nav li.chosen a ~ .count,.woocommerce .widget_layered_nav li.chosen a:before,#owp-checkout-timeline .active .timeline-wrapper,.bag-style:hover .wcmenucart-cart-icon .wcmenucart-count,.show-cart .wcmenucart-cart-icon .wcmenucart-count,.woocommerce ul.products li.product:not(.product-category) .image-wrap .button,input[type="button"],input[type="reset"],input[type="submit"],button[type="submit"],.button,#site-navigation-wrap .dropdown-menu >li.btn >a >span,.thumbnail:hover i,.post-quote-content,.omw-modal .omw-close-modal,body .contact-info-widget.big-icons li:hover i,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button{background-color:#1998d7}.current-shop-items-dropdown{border-top-color:#1998d7}.woocommerce div.product .woocommerce-tabs ul.tabs li.active a{border-bottom-color:#1998d7}.wcmenucart-details.count:before{border-color:#1998d7}.woocommerce ul.products li.product .button:hover{border-color:#1998d7}.woocommerce ul.products li.product .product-inner .added_to_cart:hover{border-color:#1998d7}.woocommerce div.product .woocommerce-tabs ul.tabs li.active a{border-color:#1998d7}.woocommerce .oceanwp-grid-list a.active{border-color:#1998d7}.woocommerce .oceanwp-grid-list a:hover{border-color:#1998d7}.woocommerce .oceanwp-off-canvas-filter:hover{border-color:#1998d7}.owp-product-nav li a.owp-nav-link:hover{border-color:#1998d7}.widget_shopping_cart_content .buttons .button:first-child:hover{border-color:#1998d7}.widget_shopping_cart ul.cart_list li .owp-grid-wrap .owp-grid a.remove:hover{border-color:#1998d7}.widget_product_categories li a:hover ~ .count{border-color:#1998d7}.woocommerce .widget_product_categories li.current-cat >a ~ .count{border-color:#1998d7}.woocommerce .widget_product_categories li.current-cat >a:before{border-color:#1998d7}.widget_layered_nav li a:hover ~ .count{border-color:#1998d7}.woocommerce .widget_layered_nav li.chosen a ~ .count{border-color:#1998d7}.woocommerce .widget_layered_nav li.chosen a:before{border-color:#1998d7}#owp-checkout-timeline.arrow .active .timeline-wrapper:before{border-top-color:#1998d7;border-bottom-color:#1998d7}#owp-checkout-timeline.arrow .active .timeline-wrapper:after{border-left-color:#1998d7;border-right-color:#1998d7}.bag-style:hover .wcmenucart-cart-icon .wcmenucart-count{border-color:#1998d7}.bag-style:hover .wcmenucart-cart-icon .wcmenucart-count:after{border-color:#1998d7}.show-cart .wcmenucart-cart-icon .wcmenucart-count{border-color:#1998d7}.show-cart .wcmenucart-cart-icon .wcmenucart-count:after{border-color:#1998d7}.woocommerce ul.products li.product:not(.product-category) .woo-product-gallery .active a{border-color:#1998d7}.woocommerce ul.products li.product:not(.product-category) .woo-product-gallery a:hover{border-color:#1998d7}.widget-title{border-color:#1998d7}blockquote{border-color:#1998d7}#searchform-dropdown{border-color:#1998d7}.dropdown-menu .sub-menu{border-color:#1998d7}.blog-entry.large-entry .blog-entry-readmore a:hover{border-color:#1998d7}.oceanwp-newsletter-form-wrap input[type="email"]:focus{border-color:#1998d7}.social-widget li.oceanwp-email a:hover{border-color:#1998d7}#respond #cancel-comment-reply-link:hover{border-color:#1998d7}body .contact-info-widget.big-icons li:hover i{border-color:#1998d7}#footer-widgets .oceanwp-newsletter-form-wrap input[type="email"]:focus{border-color:#1998d7}.woocommerce div.product div.images .open-image:hover,.woocommerce-error a:hover,.woocommerce-info a:hover,.woocommerce-message a:hover,.woocommerce ul.products li.product:not(.product-category) .image-wrap .button:hover,input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover,button[type="submit"]:hover,input[type="button"]:focus,input[type="reset"]:focus,input[type="submit"]:focus,button[type="submit"]:focus,.button:hover,#site-navigation-wrap .dropdown-menu >li.btn >a:hover >span,.post-quote-author,.omw-modal .omw-close-modal:hover,body div.wpforms-container-full .wpforms-form input[type=submit]:hover,body div.wpforms-container-full .wpforms-form button[type=submit]:hover,body div.wpforms-container-full .wpforms-form .wpforms-page-button:hover{background-color:#fbaf1b}body,.has-parallax-footer:not(.separate-layout) #main{background-color:#f0f2f5}a{color:#1998d7}a:hover{color:#fbaf1b}#main #content-wrap,.separate-layout #main #content-wrap{padding-top:75px;padding-bottom:70px}#scroll-top{background-color:#fbaf1b}#scroll-top:hover{background-color:#1998d7}#scroll-top{color:#000000}.page-numbers a,.page-numbers span:not(.elementor-screen-only),.page-links span{background-color:#fbaf1b}.page-numbers a:hover,.page-links a:hover span,.page-numbers.current,.page-numbers.current:hover{background-color:#1998d7}.page-numbers a,.page-numbers span:not(.elementor-screen-only),.page-links span{color:#000000}.page-numbers a:hover,.page-links a:hover span,.page-numbers.current,.page-numbers.current:hover{color:#ffffff}.page-numbers a,.page-numbers span:not(.elementor-screen-only),.page-links span{border-color:#fbaf1b}.page-numbers a:hover,.page-links a:hover span,.page-numbers.current,.page-numbers.current:hover{border-color:#1998d7}.theme-button,input[type="submit"],button[type="submit"],button,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button{padding:15px 30px 15px 30px}.theme-button,input[type="submit"],button[type="submit"],button,.button,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button{border-radius:50px}body .theme-button,body input[type="submit"],body button[type="submit"],body button,body .button,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button{background-color:#fbaf1b}body .theme-button:hover,body input[type="submit"]:hover,body button[type="submit"]:hover,body button:hover,body .button:hover,body div.wpforms-container-full .wpforms-form input[type=submit]:hover,body div.wpforms-container-full .wpforms-form input[type=submit]:active,body div.wpforms-container-full .wpforms-form button[type=submit]:hover,body div.wpforms-container-full .wpforms-form button[type=submit]:active,body div.wpforms-container-full .wpforms-form .wpforms-page-button:hover,body div.wpforms-container-full .wpforms-form .wpforms-page-button:active{background-color:#1998d7}body .theme-button,body input[type="submit"],body button[type="submit"],body button,body .button,body div.wpforms-container-full .wpforms-form input[type=submit],body div.wpforms-container-full .wpforms-form button[type=submit],body div.wpforms-container-full .wpforms-form .wpforms-page-button{color:#000000}/* Top Bar CSS */#top-bar-wrap,.oceanwp-top-bar-sticky{background-color:#fbaf1b}/* Header CSS */#site-logo #site-logo-inner,.oceanwp-social-menu .social-menu-inner,#site-header.full_screen-header .menu-bar-inner,.after-header-content .after-header-content-inner{height:85px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,.after-header-content-inner >a{line-height:85px}#site-header{border-color:#fbaf1b}#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-logo #site-logo-inner a img,#site-header.center-header #site-navigation-wrap .middle-site-logo a img{max-width:60px}#site-navigation-wrap .dropdown-menu >li >a{padding:0 30px}#site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a,#searchform-header-replace-close{color:#153e4d}#site-navigation-wrap .dropdown-menu >li >a:hover,.oceanwp-mobile-menu-icon a:hover,#searchform-header-replace-close:hover{color:#fbaf1b}#site-navigation-wrap .dropdown-menu >.current-menu-item >a,#site-navigation-wrap .dropdown-menu >.current-menu-ancestor >a,#site-navigation-wrap .dropdown-menu >.current-menu-item >a:hover,#site-navigation-wrap .dropdown-menu >.current-menu-ancestor >a:hover{color:#fbaf1b}#mobile-fullscreen{background-color:rgba(251,175,27,0.95)}body .sidr a,body .sidr-class-dropdown-toggle,#mobile-dropdown ul li a,#mobile-dropdown ul li a .dropdown-toggle,#mobile-fullscreen ul li a,#mobile-fullscreen .oceanwp-social-menu.simple-social ul li a{color:#000000}#mobile-fullscreen a.close .close-icon-inner,#mobile-fullscreen a.close .close-icon-inner::after{background-color:#000000}body .sidr a:hover,body .sidr-class-dropdown-toggle:hover,body .sidr-class-dropdown-toggle .fa,body .sidr-class-menu-item-has-children.active >a,body .sidr-class-menu-item-has-children.active >a >.sidr-class-dropdown-toggle,#mobile-dropdown ul li a:hover,#mobile-dropdown ul li a .dropdown-toggle:hover,#mobile-dropdown .menu-item-has-children.active >a,#mobile-dropdown .menu-item-has-children.active >a >.dropdown-toggle,#mobile-fullscreen ul li a:hover,#mobile-fullscreen .oceanwp-social-menu.simple-social ul li a:hover{color:#ffffff}#mobile-fullscreen a.close:hover .close-icon-inner,#mobile-fullscreen a.close:hover .close-icon-inner::after{background-color:#ffffff}/* Sidebar CSS */.widget-area .sidebar-box,.separate-layout .sidebar-box{margin-bottom:50px}/* Footer Widgets CSS */#footer-widgets{padding:90px 0 80px 0}#footer-widgets{background-color:#072533}#footer-widgets,#footer-widgets p,#footer-widgets li a:before,#footer-widgets .contact-info-widget span.oceanwp-contact-title,#footer-widgets .recent-posts-date,#footer-widgets .recent-posts-comments,#footer-widgets .widget-recent-posts-icons li .fa{color:#bbbdbe}#footer-widgets .footer-box a,#footer-widgets a{color:#bbbdbe}#footer-widgets .footer-box a:hover,#footer-widgets a:hover{color:#fbaf1b}/* Footer Bottom CSS */#footer-bottom{padding:25px 0 25px 0}#footer-bottom{background-color:#163342}#footer-bottom,#footer-bottom p{color:#bbbdbe}#footer-bottom a,#footer-bottom #footer-bottom-menu a{color:#fbaf1b}#footer-bottom a:hover,#footer-bottom #footer-bottom-menu a:hover{color:#1998d7}/* WooCommerce CSS */#owp-checkout-timeline .timeline-step{color:#cccccc}#owp-checkout-timeline .timeline-step{border-color:#cccccc}.woocommerce span.onsale{background-color:#fbaf1b}.woocommerce span.onsale{color:#000000}.woocommerce ul.products li.product.outofstock .outofstock-badge{background-color:#fbaf1b}.woocommerce ul.products li.product.outofstock .outofstock-badge{color:#000000}.woocommerce ul.products li.product li.category a{color:#153e4d}.woocommerce ul.products li.product li.category a:hover{color:#fbaf1b}.woocommerce ul.products li.product li.title a{color:#153e4d}.woocommerce ul.products li.product li.title a:hover{color:#fbaf1b}.woocommerce ul.products li.product .price,.woocommerce ul.products li.product .price .amount{color:#153e4d}.woocommerce ul.products li.product .price del .amount{color:#153e4d}.woocommerce ul.products li.product .button,.woocommerce ul.products li.product .product-inner .added_to_cart{background-color:#fbaf1b}.woocommerce ul.products li.product .button:hover,.woocommerce ul.products li.product .product-inner .added_to_cart:hover{background-color:#1998d7}.woocommerce ul.products li.product .button,.woocommerce ul.products li.product .product-inner .added_to_cart{color:#000000}.woocommerce ul.products li.product .button:hover,.woocommerce ul.products li.product .product-inner .added_to_cart:hover{color:#ffffff}.woocommerce ul.products li.product .button,.woocommerce ul.products li.product .product-inner .added_to_cart{border-style:none}.owp-quick-view{background-color:rgba(251,175,27,0.7)}.owp-quick-view:hover{background-color:rgba(25,152,215,0.7)}.owp-quick-view{color:#000000}.image-wrap.loading:before{border-left-color:#fbaf1b}.price,.amount{color:#153e4d}.product_meta .posted_in a,.product_meta .tagged_as a{color:#153e4d}.product_meta .posted_in a:hover,.product_meta .tagged_as a:hover{color:#fbaf1b}.owp-product-nav li a.owp-nav-link:hover{background-color:#fbaf1b}.owp-product-nav li a.owp-nav-link:hover{border-color:#fbaf1b}.woocommerce div.product .woocommerce-tabs ul.tabs{border-color:#dddddd}.woocommerce div.product .woocommerce-tabs ul.tabs li a{color:#153e4d}.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover{color:#fbaf1b}.woocommerce div.product .woocommerce-tabs ul.tabs li.active a{color:#fbaf1b}.woocommerce div.product .woocommerce-tabs ul.tabs li.active a{border-color:#fbaf1b}.woocommerce-MyAccount-navigation ul li a:before{color:#fbaf1b}.woocommerce-MyAccount-navigation ul li a:hover{color:#fbaf1b}.woocommerce-checkout .woocommerce-info a{color:#fbaf1b}/* Sticky Header CSS */.is-sticky #site-header,.ocean-sticky-top-bar-holder.is-sticky #top-bar-wrap,.is-sticky .header-top{opacity:1}/* Typography CSS */body{font-size:16px;color:#153e4d;letter-spacing:.3px}@media (max-width:768px){body{font-size:15px}}@media (max-width:480px){body{font-size:14px}}h1,h2,h3,h4,h5,h6,.theme-heading,.widget-title,.oceanwp-widget-recent-posts-title,.comment-reply-title,.entry-title,.sidebar-box .widget-title{color:#153e4d}h1{font-size:50px}h2{font-size:45px}@media (max-width:768px){h2{font-size:32px}}@media (max-width:480px){h2{font-size:24px}}#top-bar-content,#top-bar-social-alt{font-size:16px}#site-navigation-wrap .dropdown-menu >li >a,#site-header.full_screen-header .fs-dropdown-menu >li >a,#site-header.top-header #site-navigation-wrap .dropdown-menu >li >a,#site-header.center-header #site-navigation-wrap .dropdown-menu >li >a,#site-header.medium-header #site-navigation-wrap .dropdown-menu >li >a,.oceanwp-mobile-menu-icon a{font-family:Open Sans;font-weight:600;font-size:18px}.sidr-class-dropdown-menu li a,a.sidr-class-toggle-sidr-close,#mobile-dropdown ul li a,body #mobile-fullscreen ul li a{font-weight:500}.sidebar-box,.footer-box{font-size:14px}#footer-widgets .footer-box .widget-title{font-family:Poppins;font-weight:600;font-size:20px;text-transform:capitalize}#footer-bottom #copyright{font-family:Poppins;font-size:14px}
</style></head>

<body class="error404 wp-custom-logo wp-embed-responsive theme-oceanwp no-lightbox woocommerce-no-js oceanwp-theme fullscreen-mobile no-header-border default-breakpoint content-full-width content-max-width has-topbar page-header-disabled has-breadcrumbs has-blog-grid has-fixed-footer pagination-center account-side-style wpb-js-composer js-comp-ver-6.1 vc_responsive"  itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			

<div id="top-bar-wrap" class="clr top-bar-sticky">

	<div id="top-bar" class="clr container">

		
		<div id="top-bar-inner" class="clr">

			
    <div id="top-bar-content" class="clr has-content top-bar-centered">

        
        
            
                <span class="topbar-content">

                    <div class="kdp_header_contact_info_inner"> যোগাযোগঃ<a href=""><i class="fa fa-phone"></i>01719785602</a> <a href="mailto:contact@learnwithrobiul.com"><i class="fa fa-envelope"></i> contact@learnwithrobiul.com</a> <a href="https://learnwithrobiul.com/profile/"><i class="fa fa-user"></i> My Account</a></div>
                </span>

            
    </div><!-- #top-bar-content -->


		</div><!-- #top-bar-inner -->

		
	</div><!-- #top-bar -->

</div><!-- #top-bar-wrap -->


			
<header id="site-header" class="minimal-header clr fixed-scroll fixed-header has-sticky-mobile" data-height="85" itemscope="itemscope" itemtype="https://schema.org/WPHeader" role="banner">

	
		
			
			<div id="site-header-inner" class="clr container">

				
				

<div id="site-logo" class="clr" itemscope itemtype="https://schema.org/Brand">

	
	<div id="site-logo-inner" class="clr">

		<a href="https://learnwithrobiul.com/" class="custom-logo-link" rel="home"><img width="300" height="275" src="https://learnwithrobiul.com/wp-content/uploads/2020/02/logo.png" class="custom-logo" alt="" /></a>
	</div><!-- #site-logo-inner -->

	
	
</div><!-- #site-logo -->

			<div id="site-navigation-wrap" class="clr">
		
			
			
			<nav id="site-navigation" class="navigation main-navigation clr" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement" role="navigation">

				<ul id="menu-main-menu" class="main-menu dropdown-menu sf-menu"><li id="menu-item-177" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-177"><a href="https://learnwithrobiul.com/" class="menu-link"><span class="text-wrap"><i class="icon before line-icon icon-home" aria-hidden="true"></i><span class="menu-text">Home</span></span></a></li><li id="menu-item-176" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-176"><a href="https://learnwithrobiul.com/about/" class="menu-link"><span class="text-wrap"><i class="icon before line-icon icon-notebook" aria-hidden="true"></i><span class="menu-text">About</span></span></a></li><li id="menu-item-1036" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1036"><a href="https://learnwithrobiul.com/blog/" class="menu-link"><span class="text-wrap"><i class="icon before line-icon icon-note" aria-hidden="true"></i><span class="menu-text">Blog</span></span></a></li><li id="menu-item-178" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-178"><a href="https://learnwithrobiul.com/contact/" class="menu-link"><span class="text-wrap"><i class="icon before line-icon icon-support" aria-hidden="true"></i><span class="menu-text">Contact</span></span></a></li><li id="menu-item-752" class="menu-course-btn menu-item menu-item-type-post_type menu-item-object-page menu-item-752"><a href="https://learnwithrobiul.com/courses/" class="menu-link"><span class="text-wrap">Courses</span></a></li></ul>
			</nav><!-- #site-navigation -->

			
			
					</div><!-- #site-navigation-wrap -->
		
		
	
				
	<div class="oceanwp-mobile-menu-icon clr mobile-right">

		
		
		
		<a href="#" class="mobile-menu" aria-label="Mobile Menu">
							<i class="fa fa-bars" aria-hidden="true"></i>
							<span class="oceanwp-text">Menu</span>

						</a>

		
		
		
	</div><!-- #oceanwp-mobile-menu-navbar -->


			</div><!-- #site-header-inner -->

			
			
		
				
	
</header><!-- #site-header -->


			
			<main id="main" class="site-main clr"  role="main">

				
						
						<div id="content-wrap" class="container clr">

							
							<div id="primary" class="content-area clr">

								
								<div id="content" class="clr site-content">

									
									<article class="entry clr">

										
										    	<div class="error404-content clr">

													<h2 class="error-title">This page could not be found!</h2>
													<p class="error-text">We are sorry. But the page you are looking for is not available.<br />Perhaps you can try a new search.</p>
													
<form role="search" method="get" class="searchform" action="https://learnwithrobiul.com/">
	<label for="ocean-search-form-1">
		<span class="screen-reader-text">Search for:</span>
		<input type="search" id="ocean-search-form-1" class="field" autocomplete="off" placeholder="Search" name="s">
			</label>
	</form>													<a class="error-btn button" href="https://learnwithrobiul.com/">Back To Homepage</a>

												</div><!-- .error404-content -->

											
									</article><!-- .entry -->

									
								</div><!-- #content -->

								
							</div><!-- #primary -->

							
						</div><!--#content-wrap -->

						

        </main><!-- #main -->

        
        <section class="vc_section kdp-newsletter-section"><div class="vc_row wpb_row vc_row-fluid"><div class="text-section wpb_animate_when_almost_visible wpb_fadeInLeft fadeInLeft wpb_column vc_column_container vc_col-sm-2/5"><div class="vc_column-inner"><div class="wpb_wrapper"><h3 style="font-size: 28px;color: #ffffff;text-align: left" class="vc_custom_heading" >Newsletter</h3><p style="color: #ffffff;text-align: left" class="vc_custom_heading vc_custom_1580725978302" >Enter your email address &amp; get offers</p></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3/5"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  wpb_animate_when_almost_visible wpb_fadeInRight fadeInRight" >
		<div class="wpb_wrapper">
			<script>(function() {
	window.mc4wp = window.mc4wp || {
		listeners: [],
		forms: {
			on: function(evt, cb) {
				window.mc4wp.listeners.push(
					{
						event   : evt,
						callback: cb
					}
				);
			}
		}
	}
})();
</script><!-- Mailchimp for WordPress v4.7.8 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-337" method="post" data-id="337" data-name="Newsletter Form" ><div class="mc4wp-form-fields"><div class="kdp-newsletter">
  <input type="email" name="EMAIL" placeholder="Email address" required="">
  <input type="submit" value="Subscribe">
</div></div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1601382889" /><input type="hidden" name="_mc4wp_form_id" value="337" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /><div class="mc4wp-response"></div></form><!-- / Mailchimp for WordPress Plugin -->

		</div>
	</div>
</div></div></div></div></section>
        
            
<footer id="footer" class="site-footer" itemscope="itemscope" itemtype="https://schema.org/WPFooter" role="contentinfo">

    
    <div id="footer-inner" class="clr">

        

<div id="footer-widgets" class="oceanwp-row clr">

	
	<div class="footer-widgets-inner container">

        			<div class="footer-box span_1_of_4 col col-1">
				<div id="text-2" class="footer-widget widget_text clr">			<div class="textwidget"><p><img class="wp-image-717 alignleft" src="https://learnwithrobiul.com/wp-content/uploads/2020/02/footer-white-logo.png" alt="" width="130" height="119" /></p>
</div>
		</div><div id="ocean_social-2" class="footer-widget widget-oceanwp-social social-widget clr">				<ul class="oceanwp-social-icons no-transition style-light">
					<li class="oceanwp-twitter"><a href="#" title="Twitter"  target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li><li class="oceanwp-facebook"><a href="https://www.facebook.com/Robiul905008" title="Facebook"  target="_blank"><i class="fab fa-facebook" aria-hidden="true"></i></a></li><li class="oceanwp-instagram"><a href="#" title="Instagram"  target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li><li class="oceanwp-linkedin"><a href="#" title="LinkedIn"  target="_blank"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li><li class="oceanwp-youtube"><a href="http://www.youtube.com/c/RobiulHasan" title="Youtube"  target="_blank"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>				</ul>

				
			
		
			</div>			</div><!-- .footer-one-box -->

							<div class="footer-box span_1_of_4 col col-2">
					<div id="nav_menu-2" class="footer-widget widget_nav_menu clr"><h4 class="widget-title">Community</h4><div class="menu-community-container"><ul id="menu-community" class="menu"><li id="menu-item-348" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-348"><a target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/groups/455616135018538">Facebook Group</a></li>
<li id="menu-item-349" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-349"><a target="_blank" rel="noopener noreferrer" href="http://www.youtube.com/c/RobiulHasan">YouTube</a></li>
<li id="menu-item-352" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-352"><a href="https://learnwithrobiul.com/blog/">Blog</a></li>
<li id="menu-item-810" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-810"><a href="https://learnwithrobiul.com/shop/">Shop</a></li>
</ul></div></div>				</div><!-- .footer-one-box -->
						
							<div class="footer-box span_1_of_4 col col-3 ">
					<div id="nav_menu-3" class="footer-widget widget_nav_menu clr"><h4 class="widget-title">Help</h4><div class="menu-help-container"><ul id="menu-help" class="menu"><li id="menu-item-353" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-353"><a href="https://learnwithrobiul.com/contact/">Support Portal</a></li>
<li id="menu-item-727" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-727"><a href="https://learnwithrobiul.com/faqs/">FAQs</a></li>
<li id="menu-item-728" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-728"><a href="https://learnwithrobiul.com/refund-policy/">Refund Policy</a></li>
<li id="menu-item-356" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-356"><a href="https://learnwithrobiul.com/terms-condition/">Terms &#038; Condition</a></li>
<li id="menu-item-1063" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1063"><a href="https://learnwithrobiul.com/earning-disclaimer/">Earning Disclaimer</a></li>
</ul></div></div>				</div><!-- .footer-one-box -->
			
							<div class="footer-box span_1_of_4 col col-4">
					<div id="nav_menu-4" class="footer-widget widget_nav_menu clr"><h4 class="widget-title">About Me</h4><div class="menu-about-us-container"><ul id="menu-about-us" class="menu"><li id="menu-item-358" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-358"><a href="https://learnwithrobiul.com/about/">About</a></li>
<li id="menu-item-361" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-361"><a href="https://learnwithrobiul.com/contact/">Contact</a></li>
<li id="menu-item-726" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-726"><a href="https://learnwithrobiul.com/privacy-policy/">Privacy Policy</a></li>
</ul></div></div>				</div><!-- .footer-box -->
			
		
	</div><!-- .container -->

	
</div><!-- #footer-widgets -->



<div id="footer-bottom" class="clr no-footer-nav">

	
	<div id="footer-bottom-inner" class="container clr">

		
		
			<div id="copyright" class="clr" role="contentinfo">
				© Copyright 2020  Learn with Robiul. All rights reserved - Developed By <a href="https://yappobd.com/" target="_blank">YappoBD</a>			</div><!-- #copyright -->

		
	</div><!-- #footer-bottom-inner -->

	
</div><!-- #footer-bottom -->


    </div><!-- #footer-inner -->

    
</footer><!-- #footer -->
        
        
    </div><!-- #wrap -->

    
</div><!-- #outer-wrap -->



<a id="scroll-top" class="scroll-top-right" href="#"><span class="fa fa-angle-up" aria-label="Scroll to the top of the page"></span></a>



<div id="mobile-fullscreen" class="clr">

	<div id="mobile-fullscreen-inner" class="clr">

		<a href="#" class="close" aria-label="Close Menu">
			<div class="close-icon-wrap">
				<div class="close-icon-inner"></div>
			</div>
		</a>

		<nav class="clr" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement" role="navigation">

			<ul id="menu-main-menu-1" class="fs-dropdown-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-177"><a href="https://learnwithrobiul.com/"><i class="icon before line-icon icon-home" aria-hidden="true"></i><span class="menu-text">Home</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-176"><a href="https://learnwithrobiul.com/about/"><i class="icon before line-icon icon-notebook" aria-hidden="true"></i><span class="menu-text">About</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1036"><a href="https://learnwithrobiul.com/blog/"><i class="icon before line-icon icon-note" aria-hidden="true"></i><span class="menu-text">Blog</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-178"><a href="https://learnwithrobiul.com/contact/"><i class="icon before line-icon icon-support" aria-hidden="true"></i><span class="menu-text">Contact</span></a></li>
<li class="menu-course-btn menu-item menu-item-type-post_type menu-item-object-page menu-item-752"><a href="https://learnwithrobiul.com/courses/">Courses</a></li>
</ul>
		</nav>

	</div>

</div>
<script>(function() {function maybePrefixUrlField() {
	if (this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if (urlFields) {
	for (var j=0; j < urlFields.length; j++) {
		urlFields[j].addEventListener('blur', maybePrefixUrlField);
	}
}
})();</script><div id="pum-205" class="pum pum-overlay pum-theme-200 pum-theme-lightbox popmake-overlay pum-click-to-close click_open" data-popmake="{&quot;id&quot;:205,&quot;slug&quot;:&quot;home-banner-video-popup&quot;,&quot;theme_id&quot;:200,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;cookie_name&quot;:&quot;&quot;,&quot;extra_selectors&quot;:&quot;.kdp-video-popup-button-wrapper&quot;}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;custom&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;1000px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:&quot;1&quot;,&quot;location&quot;:&quot;center top&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:&quot;1&quot;,&quot;esc_press&quot;:&quot;1&quot;,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-hidden="true" >

	<div id="popmake-205" class="pum-container popmake theme-200 size-custom">

				

				

		

				<div class="pum-content popmake-content">
			<div class="vc_row wpb_row vc_row-fluid vc_custom_1582200454311"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1586112951883"><div class="wpb_wrapper">
	<div class="wpb_video_widget wpb_content_element vc_clearfix   vc_custom_1586113280128 vc_video-aspect-ratio-169 vc_video-el-width-100 vc_video-align-center" >
		<div class="wpb_wrapper">
			
			<div class="wpb_video_wrapper"><div class="oceanwp-oembed-wrap clr"><iframe title="Learnwithrobiul.com Presentation Video" width="1200" height="675" src="https://www.youtube.com/embed/RhSrR2ie_o4?feature=oembed" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div></div>
		</div>
	</div>
</div></div></div></div>
		</div>


				

				            <button type="button" class="pum-close popmake-close" aria-label="Close">
			×            </button>
		
	</div>

</div>
<div id="pum-746" class="pum pum-overlay pum-theme-200 pum-theme-lightbox popmake-overlay click_open" data-popmake="{&quot;id&quot;:746,&quot;slug&quot;:&quot;kdp-roadmap-webinar-video&quot;,&quot;theme_id&quot;:200,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;cookie_name&quot;:&quot;&quot;,&quot;extra_selectors&quot;:&quot;.kdp-roadmap-webinar&quot;}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;custom&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;1000px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:&quot;1&quot;,&quot;location&quot;:&quot;center top&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-hidden="true" >

	<div id="popmake-746" class="pum-container popmake theme-200 size-custom">

				

				

		

				<div class="pum-content popmake-content">
			<p><div class="vc_row wpb_row vc_row-fluid vc_custom_1582200454311"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_video_widget wpb_content_element vc_clearfix   vc_custom_1586113026568 vc_video-aspect-ratio-169 vc_video-el-width-100 vc_video-align-center" >
		<div class="wpb_wrapper">
			
			<div class="wpb_video_wrapper"><div class="oceanwp-oembed-wrap clr"><iframe title="KDP ROADMAP WEBINNER HOW YOU CAN EARN $1000 P/M WITH SELF PUBLISHING" width="1200" height="675" src="https://www.youtube.com/embed/H9i3eMCT6GQ?feature=oembed" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div></div>
		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div></div></p>
		</div>


				

				            <button type="button" class="pum-close popmake-close" aria-label="Close">
			×            </button>
		
	</div>

</div>
		<script src="//cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
		<script src="https://learnwithrobiul.com/wp-content/themes/oceanwp-child/inc/flexbox-gallery.js"></script>
		<link href="https://learnwithrobiul.com/wp-content/themes/oceanwp-child/inc/flexbox-gallery.css" rel="stylesheet">
		<link href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet">
		<script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		<script>
			jQuery(document).ready(function($) {
				jQuery('.kdp-home-about-counter .counter-number').counterUp({
				    delay: 100,
				    time: 5000
				});
			});
		</script>

		<script>
			jQuery(document).ready(function($) {
				jQuery('.cg-header-top-menu-search a').click(function(e) {
					e.preventDefault();
					jQuery('.site-search-toggle').trigger('click');
				});

				jQuery('.kdp-testimonial-wrapper').flexgal();

				// Home about section toggle
				jQuery('.kdp-home-about-view-btn .vc_btn3').click(function(event) {
					event.preventDefault();
					jQuery('.kdp-home-about-hide-section').slideToggle( 'slow' );

					if(jQuery(this).text() == 'View More'){
                        jQuery(this).text('Less');
                    } else {
                        jQuery(this).text('View More');
                    }
				});

				// Wrapping all Iframe in iframe-wrapper class
				var getIframeitem = jQuery('.content-item-description.lesson-description').find('iframe');
				jQuery(getIframeitem).each(function() {
					jQuery(this).wrap('<div class="iframe-wrapper"></div>');
				});

				// Wrapping all table in table-wrapper class
				var getIframeitem = jQuery('#learn-press-user-profile.current-user').find('table');
				jQuery(getIframeitem).each(function() {
					jQuery(this).wrap('<div class="table-wrapper"></div>');
				});

				// Add Search Icon 
				jQuery('.searchform #s').after('<button type="submit"><i class="fa fa-search"></i></button>');

				// Add QTY Increment/Decriment Button In Single Product
				jQuery(document).ready(function() {
					jQuery('body.single-product.woocommerce form').each(function() {
						jQuery(this).find('input.qty[type="number"]').before('<span class="kdp_qty_minus">-</span>');
						jQuery(this).find('input.qty[type="number"]').after('<span class="kdp_qty_plus">+</span>');
						jQuery(this).find('.kdp_qty_minus, input.qty[type="number"], .kdp_qty_plus').wrapAll('<div class="kdp-qty-wrap"></div>');
					
					  	const minus = jQuery(this).find('.kdp_qty_minus');
					  	const plus = jQuery(this).find('.kdp_qty_plus');
					  	const input = jQuery(this).find('input[type="number"]');
					  	minus.click(function(e) {
					    	e.preventDefault();
					    	var value = input.val();
					    	if (value > 1) {
					      		value--;
					    	}
					    input.val(value);
					  	});
					  
					  	plus.click(function(e) {
					    	e.preventDefault();
					    	var value = input.val();
					    	value++;
					    	input.val(value);
					  	})
				  	});
				});

				// Add QTY Increment/Decriment Button In Cart
				jQuery(document).ready(function() {
					jQuery('body.woocommerce-cart form tbody > tr').each(function() {
						jQuery(this).find('input.qty[type="number"]').before('<span class="kdp_qty_minus">-</span>');
						jQuery(this).find('input.qty[type="number"]').after('<span class="kdp_qty_plus">+</span>');
						jQuery(this).find('.kdp_qty_minus, input.qty[type="number"], .kdp_qty_plus').wrapAll('<div class="kdp-qty-wrap"></div>');
					
					  	const minus = jQuery(this).find('.kdp_qty_minus');
					  	const plus = jQuery(this).find('.kdp_qty_plus');
					  	const input = jQuery(this).find('input[type="number"]');
					  	minus.click(function(e) {
					    	e.preventDefault();
					    	var value = input.val();
					    	if (value > 1) {
					      		value--;
					    	}
					    input.val(value);
					  	});
					  
					  	plus.click(function(e) {
					    	e.preventDefault();
					    	var value = input.val();
					    	value++;
					    	input.val(value);
					  	})
				  	});
				});

			});

		    jQuery( function() {
		    	jQuery( '.click-bounce-efect' ).each(function(){
		    		var thatTool = jQuery(this),
		    		get_tooltipCont = thatTool.next('.tooltip-content').html();
		    		thatTool.tooltip({
	  					position: { 
	  						my: "left bottom",
	  						at: "left top-35",
	  						collision: "fit none"
	  					},
	  					content: get_tooltipCont,
	  				});
		    	});
			    
		    } );

		    jQuery(window).load(function() {
			    var CGSliderTrackHeight = jQuery('.home-post-carousel .slick-track').innerHeight();
			    var CGSliderTrackHeightPX = CGSliderTrackHeight - 280;
			    jQuery('.home-post-carousel .wcp-carousel-main-wrap .post-style-2 .wcp-content-wrap').css('height', CGSliderTrackHeightPX);
			    console.log(CGSliderTrackHeightPX);
			})
		</script>
		
		
<div id="owp-qv-wrap">
	<div class="owp-qv-container">
		<div class="owp-qv-content-wrap">
			<div class="owp-qv-content-inner">
				<a href="#" class="owp-qv-close" aria-label="Close quick preview">×</a>
				<div id="owp-qv-content" class="woocommerce single-product"></div>
			</div>
		</div>
	</div>
	<div class="owp-qv-overlay"></div>
</div>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<link rel='stylesheet' id='vc_animate-css-css'  href='https://learnwithrobiul.com/wp-content/plugins/js_composer/assets/lib/bower/animate-css/animate.min.css?ver=6.1' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/learnwithrobiul.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.2.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_b6d6347040c2b522486e814e247ac109","fragment_name":"wc_fragments_b6d6347040c2b522486e814e247ac109","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.2.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/imagesloaded.min.js?ver=3.2.0'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/js/third/woo/woo-quick-view.min.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/wp-util.min.js?ver=5.4.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=4.2.2'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/js_composer/assets/lib/bower/flexslider/jquery.flexslider-min.js?ver=6.1'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.1'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pum_vars = {"version":"1.11.0","pm_dir_url":"https:\/\/learnwithrobiul.com\/wp-content\/plugins\/popup-maker\/","ajaxurl":"https:\/\/learnwithrobiul.com\/wp-admin\/admin-ajax.php","restapi":"https:\/\/learnwithrobiul.com\/wp-json\/pum\/v1","rest_nonce":null,"default_theme":"199","debug_mode":"","disable_tracking":"","home_url":"\/","message_position":"top","core_sub_forms_enabled":"1","popups":[]};
var ajaxurl = "https:\/\/learnwithrobiul.com\/wp-admin\/admin-ajax.php";
var pum_sub_vars = {"ajaxurl":"https:\/\/learnwithrobiul.com\/wp-admin\/admin-ajax.php","message_position":"top"};
var pum_popups = {"pum-205":{"disable_on_mobile":false,"disable_on_tablet":false,"custom_height_auto":true,"scrollable_content":false,"position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"close_on_form_submission":false,"close_on_overlay_click":true,"close_on_esc_press":true,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"triggers":[{"type":"click_open","settings":{"cookie_name":"","extra_selectors":".kdp-video-popup-button-wrapper"}}],"theme_id":"200","size":"custom","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"1000px","custom_height":"380px","animation_type":"fade","animation_speed":"350","animation_origin":"center top","location":"center top","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","zindex":"1999999999","close_button_delay":"0","cookies":[],"theme_slug":"lightbox","id":205,"slug":"home-banner-video-popup"},"pum-746":{"disable_on_mobile":false,"disable_on_tablet":false,"custom_height_auto":true,"scrollable_content":false,"position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"close_on_form_submission":false,"close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"triggers":[{"type":"click_open","settings":{"cookie_name":"","extra_selectors":".kdp-roadmap-webinar"}}],"theme_id":"200","size":"custom","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"1000px","custom_height":"380px","animation_type":"fade","animation_speed":"350","animation_origin":"center top","location":"center top","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","zindex":"1999999999","close_button_delay":"0","cookies":[],"theme_slug":"lightbox","id":746,"slug":"kdp-roadmap-webinar-video"}};
/* ]]> */
</script>
<script type='text/javascript' src='//learnwithrobiul.com/wp-content/uploads/pum/pum-site-scripts.js?defer&#038;generated=1593529220&#038;ver=1.11.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var oceanwpLocalize = {"isRTL":"","menuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select","wooCartStyle":null,"ajax_url":"https:\/\/learnwithrobiul.com\/wp-admin\/admin-ajax.php","cart_url":"https:\/\/learnwithrobiul.com\/cart\/","cart_redirect_after_add":"yes","view_cart":"View cart","floating_bar":"off","grouped_text":"View products","stickyChoose":"auto","stickyStyle":"fixed","shrinkLogoHeight":"110","stickyEffect":"none","hasStickyTopBar":"1","hasStickyMobile":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/uploads/oceanwp/main-scripts.js?ver=1.0'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/ocean-sticky-header/assets/js/main.min.js'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-includes/js/wp-embed.min.js?ver=5.4.2'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/themes/oceanwp/assets/js/third/html5.min.js?ver=1.0'></script>
<![endif]-->
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/js_composer/assets/lib/vc_waypoints/vc-waypoints.min.js?ver=6.1'></script>
<script type='text/javascript' src='https://learnwithrobiul.com/wp-content/plugins/mailchimp-for-wp/assets/js/forms.min.js?ver=4.7.8'></script>
<script type='text/javascript'>
document.tidioChatCode = "5vu39babmdwioosmegxdsikgit3uwyic";
(function() {
  function asyncLoad() {
    var tidioScript = document.createElement("script");
    tidioScript.type = "text/javascript";
    tidioScript.async = true;
    tidioScript.src = "//code.tidio.co/5vu39babmdwioosmegxdsikgit3uwyic.js";
    document.body.appendChild(tidioScript);
  }
  if (window.attachEvent) {
    window.attachEvent("onload", asyncLoad);
  } else {
    window.addEventListener("load", asyncLoad, false);
  }
})();
</script></body>
</html>
<!-- Page generated by LiteSpeed Cache 3.2.3.2 on 2020-09-29 18:34:49 -->